package com.example.proyectobase.MiPackage

object MiPrimerObjeto {
}